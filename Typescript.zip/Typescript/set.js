var map = new Map();
map.set("A", 1);
map.set("B", 2);
map.set("C", 3);
